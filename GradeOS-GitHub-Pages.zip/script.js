/**
 * ============================================================================
 * GradeOS — Private Grade Management System (Vanilla JS, Web Crypto, IndexedDB)
 * ============================================================================
 * - Kein Hardcoded-Passwort im Code
 * - PBKDF2-SHA256 Schlüsselableitung (310.000 Iterationen)
 * - AES-256-GCM Verschlüsselung sämtlicher Nutzdaten in IndexedDB
 * - Zwei unabhängige Statussysteme: Bestätigung (A) & Schulmanager (B)
 * - Lückenloses Änderungsprotokoll (Notenverlauf)
 * - Individuelle Halbjahres-Gewichtung (100 %-Validierung) & Einzelgewichtung
 * - Was-wäre-wenn-Notenrechner
 * - JSON Import / Export mit Validierung, Vorschau & Intelligentem Merge
 */

(() => {
  'use strict';

  const SCHEMA_VERSION = '1.0.0';
  const DB_NAME = 'GradeOS_EncryptedVault_DB';
  const DB_VERSION = 1;
  const STORE_VAULT = 'vault_store';
  const STORE_BACKUPS = 'auto_backups';
  const PBKDF2_ITERATIONS = 310000;

  // Standard-Kategorien (alle bearbeitbar + eigene erstellbar; Mapping auf 4 Hauptgruppen für Halbjahresgewichtung)
  const DEFAULT_CATEGORIES = [
    { id: 'cat_exam', name: 'Klassenarbeit', group: 'exam', editable: true },
    { id: 'cat_test', name: 'Test', group: 'test', editable: true },
    { id: 'cat_oral', name: 'Mündlich', group: 'oral', editable: true },
    { id: 'cat_other', name: 'Sonstige Leistungen', group: 'other', editable: true },
    { id: 'cat_presentation', name: 'Referat', group: 'other', editable: true },
    { id: 'cat_project', name: 'Projekt', group: 'other', editable: true },
    { id: 'cat_practical', name: 'Praktische Leistung', group: 'other', editable: true }
  ];

  const WALLPAPER_PRESETS = {
    'sequoia-dark': {
      css: 'linear-gradient(135deg, #090d16 0%, #132a4a 52%, #0a84ff 100%)',
      theme: 'dark'
    },
    'sonoma-aurora': {
      css: 'linear-gradient(135deg, #120c29 0%, #3b1d6e 50%, #ec4899 100%)',
      theme: 'dark'
    },
    'ventura-sunset': {
      css: 'linear-gradient(135deg, #1f1118 0%, #7c2d12 50%, #f59e0b 100%)',
      theme: 'dark'
    },
    'emerald-forest': {
      css: 'linear-gradient(135deg, #061814 0%, #064e3b 52%, #10b981 100%)',
      theme: 'dark'
    },
    'pure-obsidian': {
      css: '#07090e',
      theme: 'dark'
    },
    'ios-light-sky': {
      css: 'linear-gradient(135deg, #dbeafe 0%, #e0e7ff 50%, #f3e8ff 100%)',
      theme: 'light'
    },
    'ios-mint-breeze': {
      css: 'linear-gradient(135deg, #d1fae5 0%, #e0f2fe 52%, #f8fafc 100%)',
      theme: 'light'
    },
    'alabaster-clean': {
      css: '#eef2f6',
      theme: 'light'
    }
  };

  const SUBJECT_ICONS = ['📐', '🧪', '🌍', '📚', '💻', '🎨', '🎵', '⚽', '🏛️', '🧬', '🗣️', '⚖️', '📊', '🔭', '✍️'];
  const SUBJECT_COLORS = ['#0a84ff', '#30d158', '#ff9f0a', '#ff453a', '#bf5af2', '#64d2ff', '#ff375f', '#ac8e68', '#5e5ce6', '#00c7be'];

  // Laufzeit-Zustand (nur im Arbeitsspeicher, solange entsperrt)
  const Runtime = {
    isUnlocked: false,
    cryptoKey: null,
    salt: null,
    username: '',
    data: null,
    charts: {},
    inactivityTimer: null,
    countdownInterval: null,
    lastActivity: Date.now(),
    pendingImportData: null
  };

  function createEmptyUserData(username) {
    return {
      version: SCHEMA_VERSION,
      username,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      subjects: [], // Keine voreingestellten Fächer!
      grades: [],
      categories: JSON.parse(JSON.stringify(DEFAULT_CATEGORIES)),
      history: [],
      settings: {
        wallpaperType: 'preset',
        wallpaperValue: 'sequoia-dark',
        wallpaperCustomImage: null,
        themeMode: 'dark',
        glassOpacity: 0.14,
        glassBlur: 24,
        gradeScale: 'de_1_6', // 'de_1_6' oder 'de_15_0'
        autoLockMinutes: 5
      }
    };
  }

  // ==========================================================================
  // 1. INDEXEDDB WRAPPER
  // ==========================================================================
  function openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(STORE_VAULT)) {
          db.createObjectStore(STORE_VAULT, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORE_BACKUPS)) {
          db.createObjectStore(STORE_BACKUPS, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async function dbGet(storeName, key) {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const req = tx.objectStore(storeName).get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async function dbPut(storeName, value) {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const req = tx.objectStore(storeName).put(value);
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  }

  async function dbGetAll(storeName) {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const req = tx.objectStore(storeName).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async function dbDelete(storeName, key) {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const req = tx.objectStore(storeName).delete(key);
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  }

  // ==========================================================================
  // 2. WEB CRYPTO API (PBKDF2 + AES-256-GCM)
  // ==========================================================================
  function bufToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  function base64ToBuf(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }

  async function deriveAesKey(password, saltUint8) {
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      enc.encode(password),
      { name: 'PBKDF2' },
      false,
      ['deriveKey']
    );

    return crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: saltUint8,
        iterations: PBKDF2_ITERATIONS,
        hash: 'SHA-256'
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  async function encryptPayload(dataObj, cryptoKey) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoded = new TextEncoder().encode(JSON.stringify(dataObj));
    const ciphertext = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      cryptoKey,
      encoded
    );
    return {
      iv: bufToBase64(iv),
      ciphertext: bufToBase64(ciphertext)
    };
  }

  async function decryptPayload(encryptedRecord, cryptoKey) {
    const iv = base64ToBuf(encryptedRecord.iv);
    const ciphertext = base64ToBuf(encryptedRecord.ciphertext);
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      cryptoKey,
      ciphertext
    );
    return JSON.parse(new TextDecoder().decode(decrypted));
  }

  // Speichert den gesamten Zustand verschlüsselt in IndexedDB + automatisches Snapshot-Backup
  async function saveEncryptedVault(createSnapshot = true) {
    if (!Runtime.isUnlocked || !Runtime.cryptoKey || !Runtime.data) return;
    Runtime.data.updatedAt = new Date().toISOString();
    const encrypted = await encryptPayload(Runtime.data, Runtime.cryptoKey);

    await dbPut(STORE_VAULT, {
      id: 'primary_vault',
      username: Runtime.username,
      salt: bufToBase64(Runtime.salt),
      iterations: PBKDF2_ITERATIONS,
      iv: encrypted.iv,
      ciphertext: encrypted.ciphertext,
      updatedAt: Runtime.data.updatedAt
    });

    if (createSnapshot) {
      const snapId = 'snap_' + Date.now();
      await dbPut(STORE_BACKUPS, {
        id: snapId,
        createdAt: Runtime.data.updatedAt,
        subjectCount: Runtime.data.subjects.length,
        gradeCount: Runtime.data.grades.length,
        salt: bufToBase64(Runtime.salt),
        iv: encrypted.iv,
        ciphertext: encrypted.ciphertext
      });
      // Maximal 8 automatische Snapshots behalten
      const allSnaps = await dbGetAll(STORE_BACKUPS);
      allSnaps.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      for (let i = 8; i < allSnaps.length; i++) {
        await dbDelete(STORE_BACKUPS, allSnaps[i].id);
      }
    }
  }

  // ==========================================================================
  // 3. HILFSFUNKTIONEN, FORMATIERUNG & NOTENBERECHNUNG
  // ==========================================================================
  function uid(prefix = 'id') {
    return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  }

  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function formatDate(isoOrDate) {
    if (!isoOrDate) return '—';
    const d = new Date(isoOrDate);
    if (Number.isNaN(d.getTime())) return isoOrDate;
    return d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' });
  }

  function formatDateTime(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleString('de-DE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  function formatGrade(val) {
    if (val === null || val === undefined || Number.isNaN(val)) return '—';
    const scale = Runtime.data?.settings?.gradeScale || 'de_1_6';
    if (scale === 'de_15_0') {
      return Number(val).toFixed(2).replace('.', ',') + ' P.';
    }
    return Number(val).toFixed(2).replace('.', ',');
  }

  function getGradeBadgeColor(val) {
    const scale = Runtime.data?.settings?.gradeScale || 'de_1_6';
    if (scale === 'de_15_0') {
      if (val >= 13) return '#30d158';
      if (val >= 10) return '#0a84ff';
      if (val >= 7) return '#ff9f0a';
      return '#ff453a';
    }
    if (val <= 1.75) return '#30d158';
    if (val <= 2.75) return '#0a84ff';
    if (val <= 3.75) return '#ff9f0a';
    return '#ff453a';
  }

  function showToast(message) {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'toast-item';
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(8px)';
      setTimeout(() => toast.remove(), 260);
    }, 3200);
  }

  function addHistoryEntry(type, title, detail, gradeId = null, subjectId = null) {
    if (!Runtime.data) return;
    Runtime.data.history.unshift({
      id: uid('hist'),
      timestamp: new Date().toISOString(),
      type, // 'created' | 'confirmed' | 'schoolmanager' | 'edited' | 'deleted'
      title,
      detail,
      gradeId,
      subjectId
    });
  }

  function getCategoryObj(categoryId) {
    return (
      Runtime.data.categories.find((c) => c.id === categoryId) || {
        id: categoryId,
        name: 'Sonstige Leistungen',
        group: 'other'
      }
    );
  }

  /**
   * Berechnet die Durchschnitte eines Fachs für ein bestimmtes Halbjahr (1 oder 2)
   * unter Berücksichtigung:
   * 1) Individueller Einzelgewichtungen pro Note innerhalb einer Kategorie
   * 2) Individueller Prozentgewichtung (exam, test, oral, other = 100 %) des Halbjahres
   *    (falls keine Gewichtung gesetzt wurde, wird gleichgewichtet über alle vorhandenen Noten gerechnet)
   */
  function calculateSubjectSemesterStats(subject, semesterNum) {
    const grades = Runtime.data.grades.filter(
      (g) => g.subjectId === subject.id && Number(g.semester) === Number(semesterNum)
    );

    const groups = {
      exam: [],
      test: [],
      oral: [],
      other: []
    };

    grades.forEach((g) => {
      const cat = getCategoryObj(g.categoryId);
      const grp = groups[cat.group] ? cat.group : 'other';
      groups[grp].push(g);
    });

    const groupAverages = {};
    ['exam', 'test', 'oral', 'other'].forEach((grp) => {
      const list = groups[grp];
      if (!list.length) {
        groupAverages[grp] = null;
      } else {
        let weightedSum = 0;
        let weightTotal = 0;
        list.forEach((item) => {
          const w = Number(item.weight) > 0 ? Number(item.weight) : 1;
          weightedSum += Number(item.value) * w;
          weightTotal += w;
        });
        groupAverages[grp] = weightTotal > 0 ? weightedSum / weightTotal : null;
      }
    });

    const semWeights = semesterNum === 1 ? subject.weightsH1 : subject.weightsH2;
    const hasConfiguredWeights =
      semWeights &&
      Number(semWeights.exam || 0) +
        Number(semWeights.test || 0) +
        Number(semWeights.oral || 0) +
        Number(semWeights.other || 0) ===
        100;

    let overall = null;
    if (grades.length > 0) {
      if (hasConfiguredWeights) {
        let activeWeightSum = 0;
        let weightedAvgSum = 0;
        ['exam', 'test', 'oral', 'other'].forEach((grp) => {
          const pct = Number(semWeights[grp] || 0);
          if (groupAverages[grp] !== null && pct > 0) {
            weightedAvgSum += groupAverages[grp] * pct;
            activeWeightSum += pct;
          }
        });
        if (activeWeightSum > 0) {
          overall = weightedAvgSum / activeWeightSum;
        } else {
          // Falls Noten in Kategorien mit 0%-Gewichtung liegen, fallback auf einzelgewichteten Schnitt
          let s = 0;
          let wSum = 0;
          grades.forEach((g) => {
            const w = Number(g.weight) > 0 ? Number(g.weight) : 1;
            s += Number(g.value) * w;
            wSum += w;
          });
          overall = wSum > 0 ? s / wSum : null;
        }
      } else {
        // Keine Gewichtung definiert -> arithmetisches Mittel unter Berücksichtigung der Einzelgewichtung
        let s = 0;
        let wSum = 0;
        grades.forEach((g) => {
          const w = Number(g.weight) > 0 ? Number(g.weight) : 1;
          s += Number(g.value) * w;
          wSum += w;
        });
        overall = wSum > 0 ? s / wSum : null;
      }
    }

    return {
      grades,
      count: grades.length,
      groupAverages,
      overall,
      hasConfiguredWeights
    };
  }

  function calculateSubjectYearlyAvg(subject) {
    const h1 = calculateSubjectSemesterStats(subject, 1).overall;
    const h2 = calculateSubjectSemesterStats(subject, 2).overall;
    if (h1 !== null && h2 !== null) return (h1 + h2) / 2;
    if (h1 !== null) return h1;
    if (h2 !== null) return h2;
    return null;
  }

  function calculateGlobalAverages() {
    const subjects = Runtime.data.subjects;
    const h1List = [];
    const h2List = [];
    const yearList = [];

    subjects.forEach((sub) => {
      const s1 = calculateSubjectSemesterStats(sub, 1).overall;
      const s2 = calculateSubjectSemesterStats(sub, 2).overall;
      const sy = calculateSubjectYearlyAvg(sub);
      if (s1 !== null) h1List.push(s1);
      if (s2 !== null) h2List.push(s2);
      if (sy !== null) yearList.push(sy);
    });

    const avg = (arr) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : null);
    return {
      overall: avg(yearList),
      h1: avg(h1List),
      h2: avg(h2List)
    };
  }

  // ==========================================================================
  // 4. WALLPAPER & LIQUID GLASS SETTINGS ANWENDEN
  // ==========================================================================
  function applyVisualSettings() {
    const settings = Runtime.data?.settings;
    if (!settings) return;

    const root = document.documentElement;
    const wallpaperEl = document.getElementById('app-wallpaper');
    const orbs = wallpaperEl.querySelectorAll('.liquid-orb');

    root.style.setProperty('--glass-opacity', String(settings.glassOpacity ?? 0.14));
    root.style.setProperty('--glass-blur', `${settings.glassBlur ?? 24}px`);

    if (settings.wallpaperType === 'image' && settings.wallpaperCustomImage) {
      wallpaperEl.style.background = `url("${settings.wallpaperCustomImage}") center/cover no-repeat fixed`;
      orbs.forEach((o) => (o.style.display = 'none'));
    } else if (settings.wallpaperType === 'color') {
      wallpaperEl.style.background = settings.wallpaperValue || '#0f172a';
      orbs.forEach((o) => (o.style.display = 'block'));
    } else {
      const preset = WALLPAPER_PRESETS[settings.wallpaperValue] || WALLPAPER_PRESETS['sequoia-dark'];
      wallpaperEl.style.background = preset.css;
      orbs.forEach((o) => (o.style.display = preset.theme === 'light' ? 'none' : 'block'));
    }

    root.setAttribute('data-theme', settings.themeMode || 'dark');

    // Sync Settings UI Controls
    const opSlider = document.getElementById('setting-glass-opacity');
    const blurSlider = document.getElementById('setting-glass-blur');
    if (opSlider) {
      opSlider.value = Math.round((settings.glassOpacity ?? 0.14) * 100);
      document.getElementById('label-glass-opacity').textContent = `${opSlider.value}%`;
    }
    if (blurSlider) {
      blurSlider.value = settings.glassBlur ?? 24;
      document.getElementById('label-glass-blur').textContent = `${blurSlider.value}px`;
    }
    const scaleSel = document.getElementById('setting-grade-scale');
    if (scaleSel) scaleSel.value = settings.gradeScale || 'de_1_6';

    const lockSel = document.getElementById('setting-autolock-minutes');
    if (lockSel) lockSel.value = String(settings.autoLockMinutes ?? 5);

    document.querySelectorAll('.wallpaper-swatch').forEach((btn) => {
      btn.classList.toggle('active', settings.wallpaperType === 'preset' && btn.dataset.preset === settings.wallpaperValue);
    });
  }

  // ==========================================================================
  // 5. AUTHENTIFIZIERUNG, TRESOR-SPERRE & AUTO-LOCK
  // ==========================================================================
  async function initLockScreen() {
    const existingVault = await dbGet(STORE_VAULT, 'primary_vault');
    const loginForm = document.getElementById('login-form');
    const setupForm = document.getElementById('setup-form');
    const titleEl = document.getElementById('lock-title');
    const subtitleEl = document.getElementById('lock-subtitle');

    if (existingVault) {
      loginForm.classList.remove('hidden');
      setupForm.classList.add('hidden');
      titleEl.textContent = `Willkommen zurück, ${existingVault.username}`;
      subtitleEl.textContent = 'Dein Notentresor ist mit AES-256-GCM geschützt.';
      document.getElementById('login-username').value = existingVault.username;
    } else {
      loginForm.classList.add('hidden');
      setupForm.classList.remove('hidden');
      titleEl.textContent = 'GradeOS einrichten';
      subtitleEl.textContent = 'Erstelle deinen persönlichen, lokal verschlüsselten Notentresor.';
    }
  }

  function lockApplication(reason = 'Tresor gesperrt.') {
    Runtime.isUnlocked = false;
    Runtime.cryptoKey = null;
    Runtime.data = null;
    clearInterval(Runtime.countdownInterval);

    document.getElementById('app-shell').classList.add('hidden');
    document.getElementById('lock-screen').classList.remove('hidden');
    document.getElementById('login-password').value = '';
    document.getElementById('login-error').classList.add('hidden');
    initLockScreen();
    showToast(reason);
  }

  function resetInactivityTimer() {
    Runtime.lastActivity = Date.now();
  }

  function startAutoLockWatcher() {
    clearInterval(Runtime.countdownInterval);
    ['mousemove', 'keydown', 'click', 'touchstart', 'scroll'].forEach((evt) => {
      window.addEventListener(evt, resetInactivityTimer, { passive: true });
    });

    Runtime.countdownInterval = setInterval(() => {
      if (!Runtime.isUnlocked || !Runtime.data) return;
      const mins = Number(Runtime.data.settings?.autoLockMinutes ?? 5);
      const label = document.getElementById('lock-countdown-text');
      if (!mins || mins <= 0) {
        if (label) label.textContent = 'Auto-Sperre aus';
        return;
      }
      const maxMs = mins * 60 * 1000;
      const remainingMs = Math.max(0, maxMs - (Date.now() - Runtime.lastActivity));
      const secTotal = Math.ceil(remainingMs / 1000);
      const m = Math.floor(secTotal / 60);
      const s = String(secTotal % 60).padStart(2, '0');
      if (label) label.textContent = `Auto-Sperre in ${m}:${s}`;

      if (remainingMs <= 0) {
        lockApplication('Automatische Sperre wegen Inaktivität.');
      }
    }, 1000);
  }

  async function unlockWithData(username, cryptoKey, salt, dataObj) {
    Runtime.isUnlocked = true;
    Runtime.username = username;
    Runtime.cryptoKey = cryptoKey;
    Runtime.salt = salt;
    Runtime.data = dataObj;
    Runtime.lastActivity = Date.now();

    document.getElementById('sidebar-username').textContent = username;
    document.getElementById('dashboard-greeting').textContent = `Hallo ${username} — deine verschlüsselte Schulübersicht`;

    document.getElementById('lock-screen').classList.add('hidden');
    document.getElementById('app-shell').classList.remove('hidden');

    applyVisualSettings();
    startAutoLockWatcher();
    refreshAllViews();
  }

  // ==========================================================================
  // 6. VIEW-NAVIGATION & RENDERING
  // ==========================================================================
  function switchView(viewId) {
    document.querySelectorAll('.nav-item').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.view === viewId);
    });
    document.querySelectorAll('.view-section').forEach((sec) => {
      sec.classList.toggle('active', sec.id === `view-${viewId}`);
    });
    document.getElementById('sidebar')?.classList.remove('open');
    refreshAllViews();
  }

  function refreshAllViews() {
    if (!Runtime.isUnlocked || !Runtime.data) return;
    updateNavigationBadges();
    renderDashboard();
    renderSubjectsView();
    renderGradesView();
    renderProvisionalView();
    renderHistoryView();
    renderStatisticsView();
    renderCalculatorSelectors();
    renderSettingsBackups();
    renderImportExportSummary();
  }

  function updateNavigationBadges() {
    const subjectsCount = Runtime.data.subjects.length;
    const gradesCount = Runtime.data.grades.length;
    const provCount = Runtime.data.grades.filter((g) => g.confirmationStatus === 'provisional').length;
    const unregCount = Runtime.data.grades.filter((g) => g.schoolManagerStatus === 'unregistered').length;

    document.getElementById('nav-badge-subjects').textContent = subjectsCount;
    document.getElementById('nav-badge-grades').textContent = gradesCount;
    document.getElementById('nav-badge-provisional').textContent = provCount + unregCount;

    const banner = document.getElementById('provisional-alert-banner');
    const bannerText = document.getElementById('provisional-alert-text');
    if (provCount > 0 || unregCount > 0) {
      banner.classList.remove('hidden');
      bannerText.textContent = `Hinweis: ${provCount} vorläufige Note(n) und ${unregCount} noch nicht im Schulmanager eingetragene Note(n).`;
    } else {
      banner.classList.add('hidden');
    }
  }

  // --------------------------------------------------------------------------
  // DASHBOARD RENDERING
  // --------------------------------------------------------------------------
  function renderDashboard() {
    const avgs = calculateGlobalAverages();
    const subjects = Runtime.data.subjects;
    const grades = Runtime.data.grades;

    document.getElementById('kpi-overall-avg').textContent = formatGrade(avgs.overall);
    document.getElementById('kpi-h1-avg').textContent = formatGrade(avgs.h1);
    document.getElementById('kpi-h2-avg').textContent = formatGrade(avgs.h2);
    document.getElementById('kpi-subjects-count').textContent = subjects.length;

    const h1Count = grades.filter((g) => Number(g.semester) === 1).length;
    const h2Count = grades.filter((g) => Number(g.semester) === 2).length;
    document.getElementById('kpi-h1-meta').textContent = `${h1Count} Noten erfasst`;
    document.getElementById('kpi-h2-meta').textContent = `${h2Count} Noten erfasst`;
    document.getElementById('kpi-total-grades-meta').textContent = `${grades.length} Noten insgesamt`;

    const provGrades = grades.filter((g) => g.confirmationStatus === 'provisional');
    const unregGrades = grades.filter((g) => g.schoolManagerStatus === 'unregistered');
    document.getElementById('dash-provisional-count').textContent = provGrades.length;
    document.getElementById('dash-unregistered-count').textContent = unregGrades.length;

    // Offene Status-Liste (max 4 Einträge)
    const pendingEl = document.getElementById('dash-pending-list');
    const pendingCombined = grades
      .filter((g) => g.confirmationStatus === 'provisional' || g.schoolManagerStatus === 'unregistered')
      .slice(0, 4);

    if (!pendingCombined.length) {
      pendingEl.innerHTML = `<div class="empty-state-mini">Alle Noten sind bestätigt und im Schulmanager eingetragen.</div>`;
    } else {
      pendingEl.innerHTML = pendingCombined
        .map((g) => {
          const sub = subjects.find((s) => s.id === g.subjectId);
          return `
            <div class="compact-row">
              <div>
                <strong>${escapeHtml(sub?.name || 'Unbekannt')} (${formatGrade(g.value)})</strong>
                <div style="font-size:0.75rem;color:var(--text-secondary)">
                  ${g.confirmationStatus === 'provisional' ? '⏳ Vorläufig' : '✅ Bestätigt'} ·
                  ${g.schoolManagerStatus === 'unregistered' ? '🏫 Fehlt im SM' : '🏫 Im SM'}
                </div>
              </div>
              <button type="button" class="btn-liquid-pill" data-nav-jump="provisional">Prüfen</button>
            </div>
          `;
        })
        .join('');
    }

    // Fächer-Schnellübersicht
    const subOverviewEl = document.getElementById('dash-subjects-overview');
    if (!subjects.length) {
      subOverviewEl.innerHTML = `<div class="empty-state-mini">Noch keine Fächer angelegt. Klicke oben auf „+ Fach anlegen“.</div>`;
    } else {
      subOverviewEl.innerHTML = subjects
        .map((sub) => {
          const yAvg = calculateSubjectYearlyAvg(sub);
          return `
            <div class="compact-row">
              <div style="display:flex;align-items:center;gap:10px;">
                <span style="width:28px;height:28px;border-radius:8px;background:${escapeHtml(sub.color)};display:inline-flex;align-items:center;justify-content:center;">${escapeHtml(sub.icon)}</span>
                <strong>${escapeHtml(sub.name)}</strong>
              </div>
              <strong style="font-size:1rem;">${formatGrade(yAvg)}</strong>
            </div>
          `;
        })
        .join('');
    }

    // Letzte Änderungen (5 Einträge)
    const recentHistEl = document.getElementById('dash-recent-history');
    const recentItems = Runtime.data.history.slice(0, 5);
    if (!recentItems.length) {
      recentHistEl.innerHTML = `<div class="empty-state-mini">Noch keine Aktivitäten protokolliert.</div>`;
    } else {
      recentHistEl.innerHTML = recentItems.map(renderHistoryRowHTML).join('');
    }

    renderDashboardTrendChart();
  }

  function renderDashboardTrendChart() {
    const canvas = document.getElementById('chart-dashboard-trend');
    const emptyEl = document.getElementById('dash-chart-empty');
    if (!canvas || typeof Chart === 'undefined') return;

    const semFilter = document.getElementById('dash-trend-semester')?.value || 'all';
    let filtered = [...Runtime.data.grades];
    if (semFilter !== 'all') {
      filtered = filtered.filter((g) => String(g.semester) === semFilter);
    }
    filtered.sort((a, b) => new Date(a.date) - new Date(b.date));

    if (Runtime.charts.dashTrend) {
      Runtime.charts.dashTrend.destroy();
    }

    if (!filtered.length) {
      emptyEl.classList.remove('hidden');
      return;
    }
    emptyEl.classList.add('hidden');

    const isLight = Runtime.data.settings.themeMode === 'light';
    const textColor = isLight ? '#0f172a' : '#f8fafc';
    const gridColor = isLight ? 'rgba(15,23,42,0.08)' : 'rgba(255,255,255,0.1)';
    const is1to6 = Runtime.data.settings.gradeScale !== 'de_15_0';

    Runtime.charts.dashTrend = new Chart(canvas, {
      type: 'line',
      data: {
        labels: filtered.map((g) => {
          const sub = Runtime.data.subjects.find((s) => s.id === g.subjectId);
          return `${formatDate(g.date)} (${sub?.name || '?'})`;
        }),
        datasets: [
          {
            label: 'Note',
            data: filtered.map((g) => Number(g.value)),
            borderColor: '#0a84ff',
            backgroundColor: 'rgba(10, 132, 255, 0.2)',
            borderWidth: 3,
            tension: 0.35,
            fill: true,
            pointRadius: 5,
            pointBackgroundColor: filtered.map((g) =>
              g.confirmationStatus === 'provisional' ? '#ff9f0a' : '#30d158'
            )
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: {
            reverse: is1to6,
            min: is1to6 ? 1 : 0,
            max: is1to6 ? 6 : 15,
            ticks: { color: textColor },
            grid: { color: gridColor }
          },
          x: {
            ticks: { color: textColor, maxRotation: 25 },
            grid: { display: false }
          }
        }
      }
    });
  }

  // --------------------------------------------------------------------------
  // FÄCHERVERWALTUNG RENDERING
  // --------------------------------------------------------------------------
  function renderSubjectsView() {
    const grid = document.getElementById('subjects-grid');
    const query = (document.getElementById('global-search-input')?.value || '').trim().toLowerCase();
    let subjects = Runtime.data.subjects;

    if (query) {
      subjects = subjects.filter(
        (s) =>
          s.name.toLowerCase().includes(query) ||
          (s.notes && s.notes.toLowerCase().includes(query))
      );
    }

    if (!subjects.length) {
      grid.innerHTML = `
        <div class="liquid-glass-card span-2 empty-state-box">
          <h3>Keine Fächer vorhanden</h3>
          <p class="mt-8">GradeOS startet bewusst ohne voreingestellte Fächer. Lege jetzt dein erstes eigenes Fach an.</p>
          <button type="button" class="btn-liquid-primary mt-16" onclick="document.getElementById('btn-open-create-subject').click()">+ Erstes Fach erstellen</button>
        </div>
      `;
      return;
    }

    grid.innerHTML = subjects
      .map((sub) => {
        const s1 = calculateSubjectSemesterStats(sub, 1);
        const s2 = calculateSubjectSemesterStats(sub, 2);
        const yAvg = calculateSubjectYearlyAvg(sub);
        const w1 = sub.weightsH1;
        const w2 = sub.weightsH2;

        return `
          <article class="liquid-glass-card subject-card">
            <div>
              <div class="subject-card-top">
                <div class="subject-identity">
                  <div class="subject-icon-box" style="background:${escapeHtml(sub.color)}">${escapeHtml(sub.icon)}</div>
                  <div>
                    <h3 class="subject-title">${escapeHtml(sub.name)}</h3>
                    <span style="font-size:0.78rem;color:var(--text-secondary)">${s1.count + s2.count} Noten erfasst</span>
                  </div>
                </div>
                <div class="subject-avg-badge" title="Jahresdurchschnitt">${formatGrade(yAvg)}</div>
              </div>

              <div class="subject-semesters-row mt-12">
                <div class="sem-mini-box">
                  <span>1. Halbjahr (${s1.count})</span>
                  <strong>${formatGrade(s1.overall)}</strong>
                </div>
                <div class="sem-mini-box">
                  <span>2. Halbjahr (${s2.count})</span>
                  <strong>${formatGrade(s2.overall)}</strong>
                </div>
              </div>

              <div class="subject-weights-summary mt-12">
                <div><strong>Gewichtung 1. HJ:</strong> ${
                  s1.hasConfiguredWeights
                    ? `KA ${w1.exam}% · Test ${w1.test}% · Mündl. ${w1.oral}% · Sonst. ${w1.other}%`
                    : 'Noch nicht festgelegt (Gleichgewichtung)'
                }</div>
                <div class="mt-8"><strong>Gewichtung 2. HJ:</strong> ${
                  s2.hasConfiguredWeights
                    ? `KA ${w2.exam}% · Test ${w2.test}% · Mündl. ${w2.oral}% · Sonst. ${w2.other}%`
                    : 'Noch nicht festgelegt (Gleichgewichtung)'
                }</div>
              </div>

              ${sub.notes ? `<p class="subject-notes-preview mt-12">📝 ${escapeHtml(sub.notes)}</p>` : ''}
            </div>

            <div class="subject-actions-row">
              <button type="button" class="btn-liquid-primary" data-action="add-grade-for-subject" data-id="${sub.id}">+ Note</button>
              <button type="button" class="btn-liquid-secondary" data-action="subject-stats" data-id="${sub.id}">Statistik</button>
              <button type="button" class="btn-liquid-secondary" data-action="edit-subject" data-id="${sub.id}">Bearbeiten</button>
              <button type="button" class="btn-liquid-danger" data-action="delete-subject" data-id="${sub.id}">Löschen</button>
            </div>
          </article>
        `;
      })
      .join('');
  }

  // --------------------------------------------------------------------------
  // NOTENVERWALTUNG RENDERING
  // --------------------------------------------------------------------------
  function populateGradeFilterDropdowns() {
    const subSel = document.getElementById('filter-grade-subject');
    const catSel = document.getElementById('filter-grade-category');
    if (!subSel || !catSel) return;

    const prevSub = subSel.value;
    const prevCat = catSel.value;

    subSel.innerHTML =
      `<option value="all">Alle Fächer</option>` +
      Runtime.data.subjects.map((s) => `<option value="${s.id}">${escapeHtml(s.icon)} ${escapeHtml(s.name)}</option>`).join('');
    if ([...subSel.options].some((o) => o.value === prevSub)) subSel.value = prevSub;

    catSel.innerHTML =
      `<option value="all">Alle Notenarten</option>` +
      Runtime.data.categories.map((c) => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');
    if ([...catSel.options].some((o) => o.value === prevCat)) catSel.value = prevCat;
  }

  function renderGradesView() {
    populateGradeFilterDropdowns();
    const container = document.getElementById('grades-list-container');
    const subFilter = document.getElementById('filter-grade-subject').value;
    const semFilter = document.getElementById('filter-grade-semester').value;
    const catFilter = document.getElementById('filter-grade-category').value;
    const confFilter = document.getElementById('filter-grade-confirmation').value;
    const smFilter = document.getElementById('filter-grade-sm').value;
    const query = (document.getElementById('global-search-input')?.value || '').trim().toLowerCase();

    let grades = [...Runtime.data.grades].sort((a, b) => new Date(b.date) - new Date(a.date));

    if (subFilter !== 'all') grades = grades.filter((g) => g.subjectId === subFilter);
    if (semFilter !== 'all') grades = grades.filter((g) => String(g.semester) === semFilter);
    if (catFilter !== 'all') grades = grades.filter((g) => g.categoryId === catFilter);
    if (confFilter !== 'all') grades = grades.filter((g) => g.confirmationStatus === confFilter);
    if (smFilter !== 'all') grades = grades.filter((g) => g.schoolManagerStatus === smFilter);

    if (query) {
      grades = grades.filter((g) => {
        const sub = Runtime.data.subjects.find((s) => s.id === g.subjectId);
        const cat = getCategoryObj(g.categoryId);
        return (
          (sub && sub.name.toLowerCase().includes(query)) ||
          cat.name.toLowerCase().includes(query) ||
          (g.description && g.description.toLowerCase().includes(query)) ||
          (g.remark && g.remark.toLowerCase().includes(query))
        );
      });
    }

    if (!grades.length) {
      container.innerHTML = `<div class="empty-state-box">Keine Noten für die gewählten Filter gefunden.</div>`;
      return;
    }

    container.innerHTML = grades.map((g) => renderGradeRowHTML(g)).join('');
  }

  function renderGradeRowHTML(g) {
    const sub = Runtime.data.subjects.find((s) => s.id === g.subjectId);
    const cat = getCategoryObj(g.categoryId);
    const isProv = g.confirmationStatus === 'provisional';
    const isUnreg = g.schoolManagerStatus === 'unregistered';

    return `
      <div class="grade-row-card ${isProv ? 'is-provisional' : ''}">
        <div class="grade-main-info">
          <div class="grade-value-pill" style="background:${getGradeBadgeColor(Number(g.value))}">
            ${formatGrade(g.value)}
          </div>
          <div class="grade-meta-block">
            <h4>${escapeHtml(sub?.icon || '📘')} ${escapeHtml(sub?.name || 'Gelöschtes Fach')} · ${escapeHtml(cat.name)}</h4>
            <div class="grade-meta-sub">
              ${g.semester}. Halbjahr · ${formatDate(g.date)} · Gewichtung: ${Number(g.weight || 1)}×
              ${g.description ? ` · <strong>${escapeHtml(g.description)}</strong>` : ''}
            </div>
            ${g.remark ? `<div class="grade-remark">💬 ${escapeHtml(g.remark)}</div>` : ''}
          </div>
        </div>

        <div class="grade-status-controls">
          <button type="button"
            class="status-toggle-chip ${isProv ? 'provisional' : 'confirmed'}"
            data-action="toggle-confirmation"
            data-id="${g.id}"
            title="Status A umschalten: Vorläufig / Bestätigt">
            ${isProv ? '⏳ Vorläufig' : '✅ Bestätigt'}
          </button>

          <button type="button"
            class="status-toggle-chip ${isUnreg ? 'unregistered' : 'registered'}"
            data-action="toggle-schoolmanager"
            data-id="${g.id}"
            title="Status B umschalten: Im Schulmanager eingetragen">
            ${isUnreg ? '🏫 Nicht im Schulmanager' : '🏫 Im Schulmanager'}
          </button>

          <button type="button" class="icon-btn" data-action="edit-grade" data-id="${g.id}" title="Note bearbeiten">✎</button>
          <button type="button" class="icon-btn" data-action="delete-grade" data-id="${g.id}" title="Note löschen">🗑</button>
        </div>
      </div>
    `;
  }

  // --------------------------------------------------------------------------
  // VORLÄUFIGE NOTEN & SCHULMANAGER VIEW
  // --------------------------------------------------------------------------
  function renderProvisionalView() {
    const provList = Runtime.data.grades.filter((g) => g.confirmationStatus === 'provisional');
    const unregList = Runtime.data.grades.filter((g) => g.schoolManagerStatus === 'unregistered');

    document.getElementById('count-provisional-badge').textContent = provList.length;
    document.getElementById('count-unregistered-badge').textContent = unregList.length;

    const provContainer = document.getElementById('provisional-only-list');
    const unregContainer = document.getElementById('unregistered-only-list');

    provContainer.innerHTML = provList.length
      ? provList.map((g) => renderGradeRowHTML(g)).join('')
      : `<div class="empty-state-mini">🎉 Alle Noten sind aktuell bestätigt!</div>`;

    unregContainer.innerHTML = unregList.length
      ? unregList.map((g) => renderGradeRowHTML(g)).join('')
      : `<div class="empty-state-mini">🎉 Alle Noten sind bereits im Schulmanager eingetragen!</div>`;
  }

  // --------------------------------------------------------------------------
  // NOTENVERLAUF RENDERING
  // --------------------------------------------------------------------------
  function renderHistoryRowHTML(item) {
    return `
      <div class="history-item">
        <span class="history-badge-dot ${escapeHtml(item.type)}"></span>
        <div class="history-content">
          <div class="history-title">${escapeHtml(item.title)}</div>
          <div class="history-detail">${escapeHtml(item.detail)}</div>
        </div>
        <div class="history-time">${formatDateTime(item.timestamp)}</div>
      </div>
    `;
  }

  function renderHistoryView() {
    const filter = document.getElementById('history-filter-type')?.value || 'all';
    const container = document.getElementById('full-history-timeline');
    let list = Runtime.data.history;
    if (filter !== 'all') {
      list = list.filter((h) => h.type === filter);
    }

    container.innerHTML = list.length
      ? list.map(renderHistoryRowHTML).join('')
      : `<div class="empty-state-box">Keine Verlaufseinträge für diesen Filter vorhanden.</div>`;
  }

  // --------------------------------------------------------------------------
  // STATISTIKEN & JAHRESÜBERSICHT RENDERING
  // --------------------------------------------------------------------------
  function renderStatisticsView() {
    const semFilter = document.getElementById('stats-semester-filter')?.value || 'all';
    let grades = Runtime.data.grades;
    if (semFilter !== 'all') {
      grades = grades.filter((g) => String(g.semester) === semFilter);
    }

    const groupSums = { exam: [], test: [], oral: [], other: [] };
    grades.forEach((g) => {
      const cat = getCategoryObj(g.categoryId);
      const grp = groupSums[cat.group] ? cat.group : 'other';
      groupSums[grp].push(g);
    });

    const calcWeightedGroup = (arr) => {
      if (!arr.length) return null;
      let s = 0;
      let w = 0;
      arr.forEach((x) => {
        const wt = Number(x.weight) > 0 ? Number(x.weight) : 1;
        s += Number(x.value) * wt;
        w += wt;
      });
      return w > 0 ? s / w : null;
    };

    document.getElementById('stat-avg-exam').textContent = formatGrade(calcWeightedGroup(groupSums.exam));
    document.getElementById('stat-count-exam').textContent = `${groupSums.exam.length} Leistungen`;

    document.getElementById('stat-avg-test').textContent = formatGrade(calcWeightedGroup(groupSums.test));
    document.getElementById('stat-count-test').textContent = `${groupSums.test.length} Leistungen`;

    document.getElementById('stat-avg-oral').textContent = formatGrade(calcWeightedGroup(groupSums.oral));
    document.getElementById('stat-count-oral').textContent = `${groupSums.oral.length} Leistungen`;

    document.getElementById('stat-avg-other').textContent = formatGrade(calcWeightedGroup(groupSums.other));
    document.getElementById('stat-count-other').textContent = `${groupSums.other.length} Leistungen`;

    renderStatisticsCharts(grades, semFilter);
    renderYearlyOverviewTable();
  }

  function renderStatisticsCharts(grades, semFilter) {
    if (typeof Chart === 'undefined') return;
    const isLight = Runtime.data.settings.themeMode === 'light';
    const textColor = isLight ? '#0f172a' : '#f8fafc';
    const gridColor = isLight ? 'rgba(15,23,42,0.08)' : 'rgba(255,255,255,0.1)';
    const is1to6 = Runtime.data.settings.gradeScale !== 'de_15_0';
    const subjects = Runtime.data.subjects;

    ['statSubjects', 'statSemesters', 'statDist', 'statCum'].forEach((k) => {
      if (Runtime.charts[k]) Runtime.charts[k].destroy();
    });

    // 1. Fachvergleiche
    const subCanvas = document.getElementById('chart-stats-subjects');
    if (subCanvas) {
      Runtime.charts.statSubjects = new Chart(subCanvas, {
        type: 'bar',
        data: {
          labels: subjects.map((s) => s.name),
          datasets: [
            {
              label: 'Durchschnitt',
              data: subjects.map((s) => {
                if (semFilter === '1') return calculateSubjectSemesterStats(s, 1).overall;
                if (semFilter === '2') return calculateSubjectSemesterStats(s, 2).overall;
                return calculateSubjectYearlyAvg(s);
              }),
              backgroundColor: subjects.map((s) => s.color),
              borderRadius: 10
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            y: { reverse: is1to6, min: is1to6 ? 1 : 0, max: is1to6 ? 6 : 15, ticks: { color: textColor }, grid: { color: gridColor } },
            x: { ticks: { color: textColor }, grid: { display: false } }
          }
        }
      });
    }

    // 2. Halbjahresvergleich
    const semCanvas = document.getElementById('chart-stats-semesters');
    if (semCanvas) {
      Runtime.charts.statSemesters = new Chart(semCanvas, {
        type: 'bar',
        data: {
          labels: subjects.map((s) => s.name),
          datasets: [
            {
              label: '1. Halbjahr',
              data: subjects.map((s) => calculateSubjectSemesterStats(s, 1).overall),
              backgroundColor: '#0a84ff',
              borderRadius: 8
            },
            {
              label: '2. Halbjahr',
              data: subjects.map((s) => calculateSubjectSemesterStats(s, 2).overall),
              backgroundColor: '#30d158',
              borderRadius: 8
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { labels: { color: textColor } } },
          scales: {
            y: { reverse: is1to6, min: is1to6 ? 1 : 0, max: is1to6 ? 6 : 15, ticks: { color: textColor }, grid: { color: gridColor } },
            x: { ticks: { color: textColor }, grid: { display: false } }
          }
        }
      });
    }

    // 3. Notenverteilung
    const distCanvas = document.getElementById('chart-stats-distribution');
    if (distCanvas) {
      const buckets = is1to6
        ? { '1 (sehr gut)': 0, '2 (gut)': 0, '3 (befriedigend)': 0, '4 (ausreichend)': 0, '5 (mangelhaft)': 0, '6 (ungenügend)': 0 }
        : { '13–15 P.': 0, '10–12 P.': 0, '7–9 P.': 0, '4–6 P.': 0, '1–3 P.': 0, '0 P.': 0 };

      grades.forEach((g) => {
        const v = Math.round(Number(g.value));
        if (is1to6) {
          const keys = Object.keys(buckets);
          const idx = Math.min(5, Math.max(0, v - 1));
          buckets[keys[idx]]++;
        } else {
          if (v >= 13) buckets['13–15 P.']++;
          else if (v >= 10) buckets['10–12 P.']++;
          else if (v >= 7) buckets['7–9 P.']++;
          else if (v >= 4) buckets['4–6 P.']++;
          else if (v >= 1) buckets['1–3 P.']++;
          else buckets['0 P.']++;
        }
      });

      Runtime.charts.statDist = new Chart(distCanvas, {
        type: 'doughnut',
        data: {
          labels: Object.keys(buckets),
          datasets: [
            {
              data: Object.values(buckets),
              backgroundColor: ['#30d158', '#0a84ff', '#64d2ff', '#ff9f0a', '#ff453a', '#bf5af2'],
              borderWidth: 0
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { position: 'right', labels: { color: textColor } } }
        }
      });
    }

    // 4. Kumulierte Durchschnittsentwicklung
    const cumCanvas = document.getElementById('chart-stats-cumulative');
    if (cumCanvas) {
      const sorted = [...grades].sort((a, b) => new Date(a.date) - new Date(b.date));
      let runningSum = 0;
      const cumData = sorted.map((g, idx) => {
        runningSum += Number(g.value);
        return Number((runningSum / (idx + 1)).toFixed(2));
      });

      Runtime.charts.statCum = new Chart(cumCanvas, {
        type: 'line',
        data: {
          labels: sorted.map((g) => formatDate(g.date)),
          datasets: [
            {
              label: 'Laufender Gesamtdurchschnitt',
              data: cumData,
              borderColor: '#bf5af2',
              backgroundColor: 'rgba(191, 90, 242, 0.2)',
              fill: true,
              tension: 0.3
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { labels: { color: textColor } } },
          scales: {
            y: { reverse: is1to6, min: is1to6 ? 1 : 0, max: is1to6 ? 6 : 15, ticks: { color: textColor }, grid: { color: gridColor } },
            x: { ticks: { color: textColor }, grid: { display: false } }
          }
        }
      });
    }
  }

  function renderYearlyOverviewTable() {
    const container = document.getElementById('yearly-overview-table');
    const subjects = Runtime.data.subjects;
    if (!subjects.length) {
      container.innerHTML = `<div class="empty-state-mini">Noch keine Fächer für die Jahresübersicht angelegt.</div>`;
      return;
    }

    container.innerHTML = `
      <table class="glass-table">
        <thead>
          <tr>
            <th>Fach</th>
            <th>1. HJ KA</th>
            <th>1. HJ Test</th>
            <th>1. HJ Mündl.</th>
            <th>1. HJ Sonst.</th>
            <th>1. HJ Gesamt</th>
            <th>2. HJ Gesamt</th>
            <th>Jahres-Ø</th>
          </tr>
        </thead>
        <tbody>
          ${subjects
            .map((sub) => {
              const s1 = calculateSubjectSemesterStats(sub, 1);
              const s2 = calculateSubjectSemesterStats(sub, 2);
              const y = calculateSubjectYearlyAvg(sub);
              return `
                <tr>
                  <td><strong>${escapeHtml(sub.icon)} ${escapeHtml(sub.name)}</strong></td>
                  <td>${formatGrade(s1.groupAverages.exam)}</td>
                  <td>${formatGrade(s1.groupAverages.test)}</td>
                  <td>${formatGrade(s1.groupAverages.oral)}</td>
                  <td>${formatGrade(s1.groupAverages.other)}</td>
                  <td><strong>${formatGrade(s1.overall)}</strong></td>
                  <td><strong>${formatGrade(s2.overall)}</strong></td>
                  <td><strong style="color:var(--info)">${formatGrade(y)}</strong></td>
                </tr>
              `;
            })
            .join('')}
        </tbody>
      </table>
    `;
  }

  // --------------------------------------------------------------------------
  // WAS-WÄRE-WENN-NOTENRECHNER
  // --------------------------------------------------------------------------
  function renderCalculatorSelectors() {
    const subSel = document.getElementById('whatif-subject');
    const catSel = document.getElementById('whatif-category');
    if (!subSel || !catSel) return;

    const prevSub = subSel.value;
    subSel.innerHTML = Runtime.data.subjects.length
      ? Runtime.data.subjects.map((s) => `<option value="${s.id}">${escapeHtml(s.icon)} ${escapeHtml(s.name)}</option>`).join('')
      : `<option value="">Bitte zuerst ein Fach anlegen</option>`;
    if ([...subSel.options].some((o) => o.value === prevSub)) subSel.value = prevSub;

    const prevCat = catSel.value;
    catSel.innerHTML = Runtime.data.categories
      .map((c) => `<option value="${c.id}">${escapeHtml(c.name)}</option>`)
      .join('');
    if ([...catSel.options].some((o) => o.value === prevCat)) catSel.value = prevCat;
  }

  function simulateSubjectWithExtraGrade(subject, semester, categoryId, gradeValue, gradeWeight) {
    const tempGrade = {
      id: 'sim_temp',
      subjectId: subject.id,
      semester: Number(semester),
      categoryId,
      value: Number(gradeValue),
      weight: Number(gradeWeight)
    };
    Runtime.data.grades.push(tempGrade);
    const simulatedStats = calculateSubjectSemesterStats(subject, Number(semester));
    Runtime.data.grades.pop(); // Sofort wieder entfernen, damit echte Daten unberührt bleiben!
    return simulatedStats.overall;
  }

  // --------------------------------------------------------------------------
  // MODALS: FACH ERSTELLEN / BEARBEITEN, NOTE ERSTELLEN / BEARBEITEN, KATEGORIEN
  // --------------------------------------------------------------------------
  function openModal(title, bodyHtml) {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-body').innerHTML = bodyHtml;
    document.getElementById('modal-backdrop').classList.remove('hidden');
  }

  function closeModal() {
    document.getElementById('modal-backdrop').classList.add('hidden');
    document.getElementById('modal-body').innerHTML = '';
  }

  function openSubjectModal(existingSubject = null) {
    const isEdit = Boolean(existingSubject);
    const w1 = existingSubject?.weightsH1 || { exam: '', test: '', oral: '', other: '' };
    const w2 = existingSubject?.weightsH2 || { exam: '', test: '', oral: '', other: '' };
    const selectedColor = existingSubject?.color || SUBJECT_COLORS[0];
    const selectedIcon = existingSubject?.icon || SUBJECT_ICONS[0];

    openModal(
      isEdit ? `Fach bearbeiten: ${existingSubject.name}` : 'Neues Fach erstellen',
      `
      <form id="subject-modal-form" class="stacked-form">
        <div class="input-group">
          <label for="sub-name">Fachname *</label>
          <input type="text" id="sub-name" class="glass-input" value="${escapeHtml(existingSubject?.name || '')}" placeholder="z. B. Mathematik" required />
        </div>

        <div class="two-col-inputs">
          <div class="input-group">
            <label for="sub-icon">Symbol auswählen</label>
            <select id="sub-icon" class="glass-select">
              ${SUBJECT_ICONS.map((ic) => `<option value="${ic}" ${ic === selectedIcon ? 'selected' : ''}>${ic}</option>`).join('')}
            </select>
          </div>
          <div class="input-group">
            <label for="sub-color">Farbe auswählen</label>
            <input type="color" id="sub-color" value="${escapeHtml(selectedColor)}" style="width:100%;height:42px;border-radius:12px;border:none;cursor:pointer;" />
          </div>
        </div>

        <div class="input-group">
          <label>Individuelle Gewichtung 1. Halbjahr (Summe = 100 % oder leer lassen)</label>
          <div class="four-col-inputs">
            <div><small>KA %</small><input type="number" id="w1-exam" class="glass-input" min="0" max="100" value="${w1.exam}" placeholder="0" /></div>
            <div><small>Test %</small><input type="number" id="w1-test" class="glass-input" min="0" max="100" value="${w1.test}" placeholder="0" /></div>
            <div><small>Mündl. %</small><input type="number" id="w1-oral" class="glass-input" min="0" max="100" value="${w1.oral}" placeholder="0" /></div>
            <div><small>Sonst. %</small><input type="number" id="w1-other" class="glass-input" min="0" max="100" value="${w1.other}" placeholder="0" /></div>
          </div>
        </div>

        <div class="input-group">
          <label>Individuelle Gewichtung 2. Halbjahr (Summe = 100 % oder leer lassen)</label>
          <div class="four-col-inputs">
            <div><small>KA %</small><input type="number" id="w2-exam" class="glass-input" min="0" max="100" value="${w2.exam}" placeholder="0" /></div>
            <div><small>Test %</small><input type="number" id="w2-test" class="glass-input" min="0" max="100" value="${w2.test}" placeholder="0" /></div>
            <div><small>Mündl. %</small><input type="number" id="w2-oral" class="glass-input" min="0" max="100" value="${w2.oral}" placeholder="0" /></div>
            <div><small>Sonst. %</small><input type="number" id="w2-other" class="glass-input" min="0" max="100" value="${w2.other}" placeholder="0" /></div>
          </div>
        </div>

        <div class="input-group">
          <label for="sub-notes">Persönliche Notizen zum Fach</label>
          <textarea id="sub-notes" class="glass-textarea" rows="2" placeholder="Lehrkraft, Raum, Prüfungsinfo…">${escapeHtml(existingSubject?.notes || '')}</textarea>
        </div>

        <div id="subject-form-error" class="auth-error hidden"></div>

        <div class="btn-row">
          <button type="submit" class="btn-liquid-primary">${isEdit ? 'Änderungen speichern' : 'Fach erstellen'}</button>
          <button type="button" class="btn-liquid-secondary" onclick="document.getElementById('modal-close-btn').click()">Abbrechen</button>
        </div>
      </form>
      `
    );

    document.getElementById('subject-modal-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('sub-name').value.trim();
      const icon = document.getElementById('sub-icon').value;
      const color = document.getElementById('sub-color').value;
      const notes = document.getElementById('sub-notes').value.trim();

      const parseWeights = (prefix) => {
        const raw = [
          document.getElementById(`${prefix}-exam`).value,
          document.getElementById(`${prefix}-test`).value,
          document.getElementById(`${prefix}-oral`).value,
          document.getElementById(`${prefix}-other`).value
        ];
        if (raw.every((v) => v === '')) return null;
        const nums = raw.map((v) => Number(v || 0));
        const sum = nums.reduce((a, b) => a + b, 0);
        if (sum !== 100) return { error: `Die Gewichtung für ${prefix === 'w1' ? '1. Halbjahr' : '2. Halbjahr'} ergibt ${sum} % – sie muss exakt 100 % ergeben (oder alle Felder leer lassen).` };
        return { exam: nums[0], test: nums[1], oral: nums[2], other: nums[3] };
      };

      const weightsH1 = parseWeights('w1');
      const weightsH2 = parseWeights('w2');
      const errEl = document.getElementById('subject-form-error');

      if (weightsH1?.error || weightsH2?.error) {
        errEl.textContent = weightsH1?.error || weightsH2?.error;
        errEl.classList.remove('hidden');
        return;
      }

      if (isEdit) {
        existingSubject.name = name;
        existingSubject.icon = icon;
        existingSubject.color = color;
        existingSubject.notes = notes;
        existingSubject.weightsH1 = weightsH1;
        existingSubject.weightsH2 = weightsH2;
        addHistoryEntry('edited', `Fach bearbeitet: ${name}`, 'Facheinstellungen und/oder Gewichtung aktualisiert.', null, existingSubject.id);
      } else {
        const newSub = {
          id: uid('sub'),
          name,
          icon,
          color,
          notes,
          weightsH1,
          weightsH2,
          createdAt: new Date().toISOString()
        };
        Runtime.data.subjects.push(newSub);
        addHistoryEntry('created', `Fach erstellt: ${name}`, 'Neues Fach angelegt.', null, newSub.id);
      }

      await saveEncryptedVault();
      closeModal();
      refreshAllViews();
      showToast(isEdit ? 'Fach aktualisiert.' : 'Neues Fach erstellt.');
    });
  }

  function openGradeModal(existingGrade = null, preselectedSubjectId = null) {
    if (!Runtime.data.subjects.length) {
      showToast('Bitte lege zuerst mindestens ein Fach an.');
      openSubjectModal();
      return;
    }

    const isEdit = Boolean(existingGrade);
    const today = new Date().toISOString().split('T')[0];
    const scale = Runtime.data.settings.gradeScale || 'de_1_6';
    const minVal = scale === 'de_15_0' ? 0 : 1;
    const maxVal = scale === 'de_15_0' ? 15 : 6;
    const stepVal = scale === 'de_15_0' ? '1' : '0.01';

    openModal(
      isEdit ? 'Note bearbeiten' : 'Neue Note eintragen',
      `
      <form id="grade-modal-form" class="stacked-form">
        <div class="two-col-inputs">
          <div class="input-group">
            <label for="gr-subject">Fach *</label>
            <select id="gr-subject" class="glass-select" required>
              ${Runtime.data.subjects
                .map(
                  (s) =>
                    `<option value="${s.id}" ${
                      (existingGrade?.subjectId || preselectedSubjectId) === s.id ? 'selected' : ''
                    }>${escapeHtml(s.icon)} ${escapeHtml(s.name)}</option>`
                )
                .join('')}
            </select>
          </div>
          <div class="input-group">
            <label for="gr-semester">Halbjahr *</label>
            <select id="gr-semester" class="glass-select" required>
              <option value="1" ${Number(existingGrade?.semester || 1) === 1 ? 'selected' : ''}>1. Halbjahr</option>
              <option value="2" ${Number(existingGrade?.semester) === 2 ? 'selected' : ''}>2. Halbjahr</option>
            </select>
          </div>
        </div>

        <div class="two-col-inputs">
          <div class="input-group">
            <label for="gr-value">Notenwert (${minVal} bis ${maxVal}) *</label>
            <input type="number" id="gr-value" class="glass-input" min="${minVal}" max="${maxVal}" step="${stepVal}" value="${existingGrade?.value ?? ''}" required />
          </div>
          <div class="input-group">
            <label for="gr-category">Notenart / Kategorie *</label>
            <select id="gr-category" class="glass-select" required>
              ${Runtime.data.categories
                .map(
                  (c) =>
                    `<option value="${c.id}" ${existingGrade?.categoryId === c.id ? 'selected' : ''}>${escapeHtml(c.name)}</option>`
                )
                .join('')}
            </select>
          </div>
        </div>

        <div class="two-col-inputs">
          <div class="input-group">
            <label for="gr-date">Datum *</label>
            <input type="date" id="gr-date" class="glass-input" value="${existingGrade?.date || today}" required />
          </div>
          <div class="input-group">
            <label for="gr-weight">Einzelgewichtung (z. B. 1 oder 2)</label>
            <input type="number" id="gr-weight" class="glass-input" min="0.1" max="10" step="0.1" value="${existingGrade?.weight ?? 1}" required />
          </div>
        </div>

        <div class="input-group">
          <label for="gr-description">Beschreibung / Thema</label>
          <input type="text" id="gr-description" class="glass-input" value="${escapeHtml(existingGrade?.description || '')}" placeholder="z. B. 1. Schulaufgabe Analysis" />
        </div>

        <div class="input-group">
          <label for="gr-remark">Bemerkung</label>
          <input type="text" id="gr-remark" class="glass-input" value="${escapeHtml(existingGrade?.remark || '')}" placeholder="Optionale Notiz" />
        </div>

        <div class="two-col-inputs">
          <div class="input-group">
            <label for="gr-conf-status">Status A — Bestätigung</label>
            <select id="gr-conf-status" class="glass-select">
              <option value="provisional" ${(existingGrade?.confirmationStatus || 'provisional') === 'provisional' ? 'selected' : ''}>⏳ Vorläufig</option>
              <option value="confirmed" ${existingGrade?.confirmationStatus === 'confirmed' ? 'selected' : ''}>✅ Bestätigt</option>
            </select>
          </div>
          <div class="input-group">
            <label for="gr-sm-status">Status B — Schulmanager</label>
            <select id="gr-sm-status" class="glass-select">
              <option value="unregistered" ${(existingGrade?.schoolManagerStatus || 'unregistered') === 'unregistered' ? 'selected' : ''}>🏫 Noch nicht eingetragen</option>
              <option value="registered" ${existingGrade?.schoolManagerStatus === 'registered' ? 'selected' : ''}>🏫 Bereits eingetragen</option>
            </select>
          </div>
        </div>

        <div class="btn-row">
          <button type="submit" class="btn-liquid-primary">${isEdit ? 'Note speichern' : 'Note eintragen'}</button>
          <button type="button" class="btn-liquid-secondary" onclick="document.getElementById('modal-close-btn').click()">Abbrechen</button>
        </div>
      </form>
      `
    );

    document.getElementById('grade-modal-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const subjectId = document.getElementById('gr-subject').value;
      const semester = Number(document.getElementById('gr-semester').value);
      const value = Number(document.getElementById('gr-value').value);
      const categoryId = document.getElementById('gr-category').value;
      const date = document.getElementById('gr-date').value;
      const weight = Number(document.getElementById('gr-weight').value || 1);
      const description = document.getElementById('gr-description').value.trim();
      const remark = document.getElementById('gr-remark').value.trim();
      const confirmationStatus = document.getElementById('gr-conf-status').value;
      const schoolManagerStatus = document.getElementById('gr-sm-status').value;

      const sub = Runtime.data.subjects.find((s) => s.id === subjectId);
      const cat = getCategoryObj(categoryId);

      if (isEdit) {
        const oldConf = existingGrade.confirmationStatus;
        const oldSm = existingGrade.schoolManagerStatus;
        Object.assign(existingGrade, {
          subjectId,
          semester,
          value,
          categoryId,
          date,
          weight,
          description,
          remark,
          confirmationStatus,
          schoolManagerStatus,
          updatedAt: new Date().toISOString()
        });

        addHistoryEntry(
          'edited',
          `Note bearbeitet: ${sub?.name || ''} (${formatGrade(value)})`,
          `${cat.name}, ${semester}. HJ${description ? ' – ' + description : ''}`,
          existingGrade.id,
          subjectId
        );
        if (oldConf !== confirmationStatus) {
          addHistoryEntry(
            'confirmed',
            `Bestätigungsstatus geändert: ${confirmationStatus === 'confirmed' ? 'Bestätigt' : 'Vorläufig'}`,
            `${sub?.name || ''} (${formatGrade(value)})`,
            existingGrade.id,
            subjectId
          );
        }
        if (oldSm !== schoolManagerStatus) {
          addHistoryEntry(
            'schoolmanager',
            `Schulmanager-Status geändert: ${schoolManagerStatus === 'registered' ? 'Bereits eingetragen' : 'Noch nicht eingetragen'}`,
            `${sub?.name || ''} (${formatGrade(value)})`,
            existingGrade.id,
            subjectId
          );
        }
      } else {
        const newGrade = {
          id: uid('grd'),
          subjectId,
          semester,
          value,
          categoryId,
          date,
          weight,
          description,
          remark,
          confirmationStatus,
          schoolManagerStatus,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        Runtime.data.grades.push(newGrade);
        addHistoryEntry(
          'created',
          `Note erstellt: ${sub?.name || ''} (${formatGrade(value)})`,
          `${cat.name}, ${semester}. HJ · Status: ${confirmationStatus === 'provisional' ? 'Vorläufig' : 'Bestätigt'}, ${schoolManagerStatus === 'unregistered' ? 'Nicht im SM' : 'Im SM'}`,
          newGrade.id,
          subjectId
        );
      }

      await saveEncryptedVault();
      closeModal();
      refreshAllViews();
      showToast(isEdit ? 'Note gespeichert.' : 'Note eingetragen.');
    });
  }

  function openCategoriesModal() {
    const renderCatList = () =>
      Runtime.data.categories
        .map(
          (c) => `
        <div class="compact-row">
          <div>
            <strong>${escapeHtml(c.name)}</strong>
            <span style="font-size:0.76rem;color:var(--text-secondary);margin-left:8px;">
              (Gewichtungsgruppe: ${
                c.group === 'exam'
                  ? 'Klassenarbeit'
                  : c.group === 'test'
                  ? 'Test'
                  : c.group === 'oral'
                  ? 'Mündlich'
                  : 'Sonstige'
              })
            </span>
          </div>
          <div style="display:flex;gap:6px;">
            <button type="button" class="btn-liquid-secondary" style="padding:5px 10px;font-size:0.78rem;" data-cat-rename="${c.id}">Umbenennen</button>
            ${
              Runtime.data.categories.length > 1
                ? `<button type="button" class="btn-liquid-danger" style="padding:5px 10px;font-size:0.78rem;" data-cat-delete="${c.id}">✕</button>`
                : ''
            }
          </div>
        </div>
      `
        )
        .join('');

    openModal(
      'Notenarten & Kategorien verwalten',
      `
      <div class="stacked-form">
        <div id="modal-cat-list" class="compact-list">${renderCatList()}</div>
        <hr class="glass-divider" />
        <form id="add-category-form" class="two-col-inputs">
          <div class="input-group">
            <label for="new-cat-name">Neue Kategorie</label>
            <input type="text" id="new-cat-name" class="glass-input" placeholder="z. B. Vokabeltest" required />
          </div>
          <div class="input-group">
            <label for="new-cat-group">Zählt in Gewichtung als</label>
            <select id="new-cat-group" class="glass-select">
              <option value="exam">Klassenarbeit</option>
              <option value="test">Test</option>
              <option value="oral">Mündlich</option>
              <option value="other" selected>Sonstige Leistungen</option>
            </select>
          </div>
          <button type="submit" class="btn-liquid-primary" style="grid-column:span 2;">Kategorie hinzufügen</button>
        </form>
      </div>
      `
    );

    document.getElementById('add-category-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('new-cat-name').value.trim();
      const group = document.getElementById('new-cat-group').value;
      if (!name) return;
      Runtime.data.categories.push({ id: uid('cat'), name, group, editable: true });
      await saveEncryptedVault();
      openCategoriesModal();
      refreshAllViews();
      showToast('Kategorie hinzugefügt.');
    });

    document.getElementById('modal-cat-list').addEventListener('click', async (e) => {
      const renId = e.target.dataset.catRename;
      const delId = e.target.dataset.catDelete;
      if (renId) {
        const cat = Runtime.data.categories.find((c) => c.id === renId);
        const nextName = prompt('Neuer Name für diese Notenart:', cat.name);
        if (nextName && nextName.trim()) {
          cat.name = nextName.trim();
          await saveEncryptedVault();
          openCategoriesModal();
          refreshAllViews();
        }
      } else if (delId) {
        Runtime.data.categories = Runtime.data.categories.filter((c) => c.id !== delId);
        await saveEncryptedVault();
        openCategoriesModal();
        refreshAllViews();
      }
    });
  }

  function openSubjectStatsModal(subject) {
    const s1 = calculateSubjectSemesterStats(subject, 1);
    const s2 = calculateSubjectSemesterStats(subject, 2);
    const yAvg = calculateSubjectYearlyAvg(subject);

    openModal(
      `${subject.icon} Fachstatistik: ${subject.name}`,
      `
      <div class="stacked-form">
        <div class="kpi-grid" style="grid-template-columns:repeat(3,1fr);">
          <div class="sem-mini-box"><span>1. Halbjahr</span><strong>${formatGrade(s1.overall)}</strong></div>
          <div class="sem-mini-box"><span>2. Halbjahr</span><strong>${formatGrade(s2.overall)}</strong></div>
          <div class="sem-mini-box"><span>Jahres-Ø</span><strong>${formatGrade(yAvg)}</strong></div>
        </div>
        <table class="glass-table">
          <thead><tr><th>Kategorie</th><th>1. Halbjahr Ø</th><th>2. Halbjahr Ø</th></tr></thead>
          <tbody>
            <tr><td>Klassenarbeiten</td><td>${formatGrade(s1.groupAverages.exam)}</td><td>${formatGrade(s2.groupAverages.exam)}</td></tr>
            <tr><td>Tests</td><td>${formatGrade(s1.groupAverages.test)}</td><td>${formatGrade(s2.groupAverages.test)}</td></tr>
            <tr><td>Mündlich</td><td>${formatGrade(s1.groupAverages.oral)}</td><td>${formatGrade(s2.groupAverages.oral)}</td></tr>
            <tr><td>Sonstige Leistungen</td><td>${formatGrade(s1.groupAverages.other)}</td><td>${formatGrade(s2.groupAverages.other)}</td></tr>
          </tbody>
        </table>
      </div>
      `
    );
  }

  // ==========================================================================
  // 7. BACKUPS & JSON IMPORT / EXPORT
  // ==========================================================================
  async function renderSettingsBackups() {
    const container = document.getElementById('auto-backups-list');
    if (!container) return;
    const snaps = await dbGetAll(STORE_BACKUPS);
    snaps.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    if (!snaps.length) {
      container.innerHTML = `<div class="empty-state-mini">Noch keine automatischen Snapshots vorhanden.</div>`;
      return;
    }

    container.innerHTML = snaps
      .map(
        (s) => `
        <div class="compact-row">
          <div>
            <strong>Snapshot vom ${formatDateTime(s.createdAt)}</strong>
            <div style="font-size:0.75rem;color:var(--text-secondary)">${s.subjectCount} Fächer · ${s.gradeCount} Noten</div>
          </div>
          <button type="button" class="btn-liquid-secondary" style="padding:5px 10px;font-size:0.78rem;" data-restore-snap="${s.id}">Wiederherstellen</button>
        </div>
      `
      )
      .join('');
  }

  function renderImportExportSummary() {
    const el = document.getElementById('export-stats-summary');
    if (!el || !Runtime.data) return;
    el.innerHTML = `
      <div class="compact-row"><span>Format-Version</span><strong>GradeOS v${SCHEMA_VERSION}</strong></div>
      <div class="compact-row mt-8"><span>Enthaltene Fächer</span><strong>${Runtime.data.subjects.length}</strong></div>
      <div class="compact-row mt-8"><span>Enthaltene Noten</span><strong>${Runtime.data.grades.length}</strong></div>
      <div class="compact-row mt-8"><span>Notenverlauf-Einträge</span><strong>${Runtime.data.history.length}</strong></div>
    `;
  }

  function validateImportedJson(obj) {
    if (!obj || typeof obj !== 'object') return 'Ungültige JSON-Struktur.';
    if (obj.app !== 'GradeOS' || !obj.version) return 'Diese Datei ist kein gültiger GradeOS-Export.';
    if (!Array.isArray(obj.subjects) || !Array.isArray(obj.grades)) return 'Fehlende Fächer- oder Notenlisten in der JSON-Datei.';
    return null;
  }

  function mergeById(localArr, incomingArr) {
    const map = new Map();
    localArr.forEach((item) => map.set(item.id, item));
    incomingArr.forEach((inc) => {
      const existing = map.get(inc.id);
      if (!existing) {
        map.set(inc.id, inc);
      } else {
        const localTime = new Date(existing.updatedAt || existing.createdAt || 0).getTime();
        const incTime = new Date(inc.updatedAt || inc.createdAt || 0).getTime();
        if (incTime >= localTime) {
          map.set(inc.id, inc);
        }
      }
    });
    return Array.from(map.values());
  }

  // ==========================================================================
  // 8. EVENT LISTENERS INITIALISIEREN
  // ==========================================================================
  function bindEvents() {
    // Passwort anzeigen / verbergen
    document.querySelectorAll('.toggle-pw-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const target = document.getElementById(btn.dataset.target);
        if (!target) return;
        const isPw = target.type === 'password';
        target.type = isPw ? 'text' : 'password';
        btn.querySelector('.eye-open')?.classList.toggle('hidden', isPw);
        btn.querySelector('.eye-closed')?.classList.toggle('hidden', !isPw);
      });
    });

    // Passwortstärke-Anzeige beim Setup
    document.getElementById('setup-password')?.addEventListener('input', (e) => {
      const val = e.target.value;
      const bar = document.getElementById('pw-strength-bar');
      let score = 0;
      if (val.length >= 6) score += 30;
      if (val.length >= 10) score += 25;
      if (/[A-Z]/.test(val) && /[a-z]/.test(val)) score += 20;
      if (/[0-9!@#$%^&*]/.test(val)) score += 25;
      bar.style.width = `${Math.min(100, score)}%`;
      bar.style.background = score < 50 ? '#ff453a' : score < 80 ? '#ff9f0a' : '#30d158';
    });

    // Setup Formular absenden
    document.getElementById('setup-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const username = document.getElementById('setup-username').value.trim();
      const pw1 = document.getElementById('setup-password').value;
      const pw2 = document.getElementById('setup-password-confirm').value;
      const errEl = document.getElementById('setup-error');

      if (pw1 !== pw2) {
        errEl.textContent = 'Die beiden Passwörter stimmen nicht überein.';
        errEl.classList.remove('hidden');
        return;
      }

      const salt = crypto.getRandomValues(new Uint8Array(16));
      const cryptoKey = await deriveAesKey(pw1, salt);
      const initialData = createEmptyUserData(username);

      Runtime.isUnlocked = true;
      Runtime.username = username;
      Runtime.cryptoKey = cryptoKey;
      Runtime.salt = salt;
      Runtime.data = initialData;

      await saveEncryptedVault(true);
      await unlockWithData(username, cryptoKey, salt, initialData);
      showToast('Verschlüsselter Tresor erfolgreich eingerichtet!');
    });

    // Login Formular absenden
    document.getElementById('login-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const usernameInput = document.getElementById('login-username').value.trim();
      const pwInput = document.getElementById('login-password').value;
      const errEl = document.getElementById('login-error');
      const lockCard = document.querySelector('.lock-card');

      try {
        const vault = await dbGet(STORE_VAULT, 'primary_vault');
        if (!vault) throw new Error('Kein Tresor gefunden.');

        if (usernameInput.toLowerCase() !== vault.username.toLowerCase()) {
          throw new Error('Benutzername oder Passwort ist nicht korrekt.');
        }

        const salt = base64ToBuf(vault.salt);
        const cryptoKey = await deriveAesKey(pwInput, salt);
        const decryptedData = await decryptPayload(vault, cryptoKey);

        errEl.classList.add('hidden');
        await unlockWithData(vault.username, cryptoKey, salt, decryptedData);
      } catch (err) {
        errEl.textContent = 'Zugangsdaten ungültig oder Entschlüsselung fehlgeschlagen.';
        errEl.classList.remove('hidden');
        lockCard.classList.remove('shake-error');
        void lockCard.offsetWidth;
        lockCard.classList.add('shake-error');
      }
    });

    // Tresor zurücksetzen
    document.getElementById('btn-reset-vault-prompt')?.addEventListener('click', async () => {
      if (confirm('Möchtest du wirklich den lokalen Tresor vollständig löschen und neu einrichten? Alle ungesicherten Daten gehen verloren.')) {
        await dbDelete(STORE_VAULT, 'primary_vault');
        initLockScreen();
        showToast('Lokaler Tresor wurde zurückgesetzt.');
      }
    });

    // Backup-JSON direkt auf dem Sperrbildschirm wiederherstellen
    document.getElementById('btn-show-restore-vault')?.addEventListener('click', () => {
      openModal(
        'Tresor aus JSON-Backup neu anlegen',
        `
        <form id="lock-restore-form" class="stacked-form">
          <p class="card-subtitle">Wähle deine exportierte GradeOS-JSON-Datei und lege ein neues Master-Passwort für dieses Gerät fest.</p>
          <input type="file" id="lock-restore-file" accept=".json,application/json" required />
          <input type="text" id="lock-restore-user" class="glass-input" placeholder="Benutzername" required />
          <input type="password" id="lock-restore-pw" class="glass-input" placeholder="Neues Master-Passwort (mind. 6 Zeichen)" minlength="6" required />
          <button type="submit" class="btn-liquid-primary">Wiederherstellen &amp; verschlüsseln</button>
        </form>
        `
      );
      document.getElementById('lock-restore-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const file = document.getElementById('lock-restore-file').files[0];
        const username = document.getElementById('lock-restore-user').value.trim();
        const pw = document.getElementById('lock-restore-pw').value;
        if (!file) return;
        try {
          const parsed = JSON.parse(await file.text());
          const err = validateImportedJson(parsed);
          if (err) {
            alert(err);
            return;
          }
          const salt = crypto.getRandomValues(new Uint8Array(16));
          const key = await deriveAesKey(pw, salt);
          const restored = Object.assign(createEmptyUserData(username), {
            username,
            subjects: parsed.subjects || [],
            grades: parsed.grades || [],
            categories: parsed.categories || DEFAULT_CATEGORIES,
            history: parsed.history || [],
            settings: Object.assign(createEmptyUserData(username).settings, parsed.settings || {})
          });
          Runtime.isUnlocked = true;
          Runtime.username = username;
          Runtime.cryptoKey = key;
          Runtime.salt = salt;
          Runtime.data = restored;
          await saveEncryptedVault(true);
          closeModal();
          await unlockWithData(username, key, salt, restored);
          showToast('JSON-Backup erfolgreich wiederhergestellt!');
        } catch (ex) {
          alert('Fehler beim Lesen der JSON-Datei: ' + ex.message);
        }
      });
    });

    // Navigation & Quick Jumps
    document.querySelectorAll('.nav-item').forEach((btn) => {
      btn.addEventListener('click', () => switchView(btn.dataset.view));
    });

    document.body.addEventListener('click', async (e) => {
      const jumpTarget = e.target.closest('[data-nav-jump]')?.dataset.navJump;
      if (jumpTarget) {
        switchView(jumpTarget);
        return;
      }

      const actionBtn = e.target.closest('[data-action]');
      if (actionBtn) {
        const action = actionBtn.dataset.action;
        const id = actionBtn.dataset.id;

        if (action === 'add-grade-for-subject') {
          openGradeModal(null, id);
        } else if (action === 'edit-subject') {
          const sub = Runtime.data.subjects.find((s) => s.id === id);
          if (sub) openSubjectModal(sub);
        } else if (action === 'delete-subject') {
          const sub = Runtime.data.subjects.find((s) => s.id === id);
          if (sub && confirm(`Fach „${sub.name}“ und alle zugehörigen Noten wirklich löschen?`)) {
            Runtime.data.subjects = Runtime.data.subjects.filter((s) => s.id !== id);
            Runtime.data.grades = Runtime.data.grades.filter((g) => g.subjectId !== id);
            addHistoryEntry('deleted', `Fach gelöscht: ${sub.name}`, 'Inklusive zugehöriger Noten entfernt.', null, id);
            await saveEncryptedVault();
            refreshAllViews();
            showToast('Fach gelöscht.');
          }
        } else if (action === 'subject-stats') {
          const sub = Runtime.data.subjects.find((s) => s.id === id);
          if (sub) openSubjectStatsModal(sub);
        } else if (action === 'toggle-confirmation') {
          const g = Runtime.data.grades.find((x) => x.id === id);
          if (g) {
            g.confirmationStatus = g.confirmationStatus === 'provisional' ? 'confirmed' : 'provisional';
            g.updatedAt = new Date().toISOString();
            const sub = Runtime.data.subjects.find((s) => s.id === g.subjectId);
            addHistoryEntry(
              'confirmed',
              `Status A geändert: ${g.confirmationStatus === 'confirmed' ? 'Bestätigt' : 'Vorläufig'}`,
              `${sub?.name || ''} (${formatGrade(g.value)})`,
              g.id,
              g.subjectId
            );
            await saveEncryptedVault();
            refreshAllViews();
            showToast(g.confirmationStatus === 'confirmed' ? 'Note als bestätigt markiert.' : 'Note auf vorläufig gesetzt.');
          }
        } else if (action === 'toggle-schoolmanager') {
          const g = Runtime.data.grades.find((x) => x.id === id);
          if (g) {
            g.schoolManagerStatus = g.schoolManagerStatus === 'unregistered' ? 'registered' : 'unregistered';
            g.updatedAt = new Date().toISOString();
            const sub = Runtime.data.subjects.find((s) => s.id === g.subjectId);
            addHistoryEntry(
              'schoolmanager',
              `Status B (Schulmanager): ${g.schoolManagerStatus === 'registered' ? 'Bereits eingetragen' : 'Noch nicht eingetragen'}`,
              `${sub?.name || ''} (${formatGrade(g.value)})`,
              g.id,
              g.subjectId
            );
            await saveEncryptedVault();
            refreshAllViews();
            showToast(g.schoolManagerStatus === 'registered' ? 'Als im Schulmanager eingetragen markiert.' : 'Als noch nicht eingetragen markiert.');
          }
        } else if (action === 'edit-grade') {
          const g = Runtime.data.grades.find((x) => x.id === id);
          if (g) openGradeModal(g);
        } else if (action === 'delete-grade') {
          const g = Runtime.data.grades.find((x) => x.id === id);
          if (g && confirm('Diese Note wirklich löschen?')) {
            const sub = Runtime.data.subjects.find((s) => s.id === g.subjectId);
            Runtime.data.grades = Runtime.data.grades.filter((x) => x.id !== id);
            addHistoryEntry('deleted', `Note gelöscht: ${sub?.name || ''} (${formatGrade(g.value)})`, `${g.semester}. Halbjahr`, id, g.subjectId);
            await saveEncryptedVault();
            refreshAllViews();
            showToast('Note gelöscht.');
          }
        }
      }

      // Snapshot wiederherstellen
      const snapId = e.target.dataset.restoreSnap;
      if (snapId) {
        const snaps = await dbGetAll(STORE_BACKUPS);
        const snap = snaps.find((s) => s.id === snapId);
        if (snap && confirm('Möchtest du diesen Snapshot wiederherstellen?')) {
          try {
            const restored = await decryptPayload(snap, Runtime.cryptoKey);
            Runtime.data = restored;
            await saveEncryptedVault(false);
            applyVisualSettings();
            refreshAllViews();
            showToast('Snapshot erfolgreich wiederhergestellt!');
          } catch {
            showToast('Snapshot konnte nicht mit dem aktuellen Schlüssel entschlüsselt werden.');
          }
        }
      }
    });

    // Mobile Menu & Sperr-Buttons
    document.getElementById('mobile-menu-toggle')?.addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('open');
    });
    document.getElementById('btn-lock-now')?.addEventListener('click', () => lockApplication('Manuell gesperrt.'));
    document.getElementById('mobile-lock-btn')?.addEventListener('click', () => lockApplication('Manuell gesperrt.'));

    // Quick Action Buttons
    document.getElementById('dash-quick-subject')?.addEventListener('click', () => openSubjectModal());
    document.getElementById('btn-open-create-subject')?.addEventListener('click', () => openSubjectModal());
    document.getElementById('dash-quick-grade')?.addEventListener('click', () => openGradeModal());
    document.getElementById('btn-open-create-grade')?.addEventListener('click', () => openGradeModal());
    document.getElementById('btn-prov-add-grade')?.addEventListener('click', () => openGradeModal());
    document.getElementById('btn-manage-categories')?.addEventListener('click', () => openCategoriesModal());
    document.getElementById('modal-close-btn')?.addEventListener('click', closeModal);

    // Filter & Suche
    ['filter-grade-subject', 'filter-grade-semester', 'filter-grade-category', 'filter-grade-confirmation', 'filter-grade-sm'].forEach((id) => {
      document.getElementById(id)?.addEventListener('change', renderGradesView);
    });
    document.getElementById('global-search-input')?.addEventListener('input', () => {
      renderSubjectsView();
      renderGradesView();
    });
    document.getElementById('dash-trend-semester')?.addEventListener('change', renderDashboardTrendChart);
    document.getElementById('history-filter-type')?.addEventListener('change', renderHistoryView);
    document.getElementById('stats-semester-filter')?.addEventListener('change', renderStatisticsView);

    // Was-wäre-wenn-Notenrechner
    document.getElementById('whatif-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      const subId = document.getElementById('whatif-subject').value;
      const sem = Number(document.getElementById('whatif-semester').value);
      const catId = document.getElementById('whatif-category').value;
      const target = Number(document.getElementById('whatif-target-avg').value);
      const weight = Number(document.getElementById('whatif-weight').value || 1);
      const resultBox = document.getElementById('whatif-result-box');

      const subject = Runtime.data.subjects.find((s) => s.id === subId);
      if (!subject) return;

      const currentAvg = calculateSubjectSemesterStats(subject, sem).overall;
      const is1to6 = Runtime.data.settings.gradeScale !== 'de_15_0';
      const minG = is1to6 ? 1.0 : 0.0;
      const maxG = is1to6 ? 6.0 : 15.0;

      // Numerische Zielwert-Suche (exakt für beliebige Fach- und Einzelgewichtungen)
      let bestGrade = null;
      let bestDiff = Infinity;
      for (let g = minG; g <= maxG + 0.001; g += 0.01) {
        const simAvg = simulateSubjectWithExtraGrade(subject, sem, catId, g, weight);
        const diff = Math.abs(simAvg - target);
        if (diff < bestDiff) {
          bestDiff = diff;
          bestGrade = Number(g.toFixed(2));
        }
      }

      const resultingAvg = simulateSubjectWithExtraGrade(subject, sem, catId, bestGrade, weight);
      const achievable = is1to6 ? resultingAvg <= target + 0.05 : resultingAvg >= target - 0.05;

      resultBox.innerHTML = `
        <div>Aktueller Schnitt in <strong>${escapeHtml(subject.name)} (${sem}. HJ)</strong>: <strong>${formatGrade(currentAvg)}</strong></div>
        <div class="mt-12">Für deinen Zielschnitt von <strong>${formatGrade(target)}</strong> benötigst du mindestens:</div>
        <div class="whatif-big-number" style="color:${achievable ? 'var(--success)' : 'var(--warning)'}">${formatGrade(bestGrade)}</div>
        <div style="font-size:0.86rem;color:var(--text-secondary)">
          ${
            achievable
              ? `Damit erreichst du voraussichtlich einen Schnitt von ${formatGrade(resultingAvg)}.`
              : `Hinweis: Selbst mit der Bestnote (${formatGrade(is1to6 ? 1 : 15)}) liegt der erreichbare Schnitt bei ${formatGrade(resultingAvg)}.`
          }
        </div>
      `;
    });

    document.getElementById('btn-whatif-simulate-grade')?.addEventListener('click', () => {
      const subId = document.getElementById('whatif-subject').value;
      const sem = Number(document.getElementById('whatif-semester').value);
      const catId = document.getElementById('whatif-category').value;
      const hypo = Number(document.getElementById('whatif-hypo-grade').value);
      const weight = Number(document.getElementById('whatif-weight').value || 1);
      const subject = Runtime.data.subjects.find((s) => s.id === subId);
      if (!subject || Number.isNaN(hypo)) return;

      const before = calculateSubjectSemesterStats(subject, sem).overall;
      const after = simulateSubjectWithExtraGrade(subject, sem, catId, hypo, weight);
      document.getElementById('whatif-result-box').innerHTML = `
        <div>Simulation für <strong>${escapeHtml(subject.name)} (${sem}. HJ)</strong> bei Note <strong>${formatGrade(hypo)}</strong>:</div>
        <div class="whatif-big-number">${formatGrade(before)} → ${formatGrade(after)}</div>
        <div style="font-size:0.85rem;color:var(--text-secondary)">Deine gespeicherten Noten wurden nicht verändert.</div>
      `;
    });

    // Einstellungen: Wallpapers, Glass-Slider, Notenskala, Auto-Lock
    document.getElementById('wallpaper-presets')?.addEventListener('click', async (e) => {
      const btn = e.target.closest('.wallpaper-swatch');
      if (!btn) return;
      const presetKey = btn.dataset.preset;
      Runtime.data.settings.wallpaperType = 'preset';
      Runtime.data.settings.wallpaperValue = presetKey;
      Runtime.data.settings.themeMode = WALLPAPER_PRESETS[presetKey]?.theme || 'dark';
      applyVisualSettings();
      await saveEncryptedVault(false);
    });

    document.getElementById('btn-apply-custom-color')?.addEventListener('click', async () => {
      const hex = document.getElementById('setting-custom-color').value;
      Runtime.data.settings.wallpaperType = 'color';
      Runtime.data.settings.wallpaperValue = hex;
      // Helligkeit berechnen für automatische Schriftfarbe
      const r = parseInt(hex.slice(1, 3), 16);
      const g = parseInt(hex.slice(3, 5), 16);
      const b = parseInt(hex.slice(5, 7), 16);
      const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
      Runtime.data.settings.themeMode = lum > 0.62 ? 'light' : 'dark';
      applyVisualSettings();
      await saveEncryptedVault(false);
      showToast('Eigene Hintergrundfarbe gespeichert.');
    });

    document.getElementById('setting-wallpaper-upload')?.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = async () => {
        Runtime.data.settings.wallpaperType = 'image';
        Runtime.data.settings.wallpaperCustomImage = reader.result;
        applyVisualSettings();
        await saveEncryptedVault(false);
        showToast('Eigenes Hintergrundbild gespeichert.');
      };
      reader.readAsDataURL(file);
    });

    document.getElementById('setting-glass-opacity')?.addEventListener('input', async (e) => {
      Runtime.data.settings.glassOpacity = Number(e.target.value) / 100;
      applyVisualSettings();
      await saveEncryptedVault(false);
    });

    document.getElementById('setting-glass-blur')?.addEventListener('input', async (e) => {
      Runtime.data.settings.glassBlur = Number(e.target.value);
      applyVisualSettings();
      await saveEncryptedVault(false);
    });

    document.getElementById('setting-grade-scale')?.addEventListener('change', async (e) => {
      Runtime.data.settings.gradeScale = e.target.value;
      await saveEncryptedVault(false);
      refreshAllViews();
      showToast('Notenskala aktualisiert.');
    });

    document.getElementById('setting-autolock-minutes')?.addEventListener('change', async (e) => {
      Runtime.data.settings.autoLockMinutes = Number(e.target.value);
      resetInactivityTimer();
      await saveEncryptedVault(false);
      showToast('Auto-Sperrzeit gespeichert.');
    });

    // Passwort ändern
    document.getElementById('change-password-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const cur = document.getElementById('cp-current').value;
      const next = document.getElementById('cp-new').value;
      const conf = document.getElementById('cp-confirm').value;

      if (next !== conf) {
        showToast('Neue Passwörter stimmen nicht überein.');
        return;
      }

      try {
        const vault = await dbGet(STORE_VAULT, 'primary_vault');
        const oldKey = await deriveAesKey(cur, base64ToBuf(vault.salt));
        await decryptPayload(vault, oldKey); // Prüft aktuelles Passwort

        const newSalt = crypto.getRandomValues(new Uint8Array(16));
        const newKey = await deriveAesKey(next, newSalt);
        Runtime.salt = newSalt;
        Runtime.cryptoKey = newKey;
        await saveEncryptedVault(true);
        e.target.reset();
        showToast('Master-Passwort & Verschlüsselungsschlüssel erfolgreich geändert!');
      } catch {
        showToast('Das aktuelle Passwort ist falsch.');
      }
    });

    // JSON Export
    document.getElementById('btn-export-json')?.addEventListener('click', () => {
      const exportPayload = {
        app: 'GradeOS',
        version: SCHEMA_VERSION,
        exportedAt: new Date().toISOString(),
        username: Runtime.username,
        subjects: Runtime.data.subjects,
        grades: Runtime.data.grades,
        categories: Runtime.data.categories,
        history: Runtime.data.history,
        settings: Runtime.data.settings
      };

      const blob = new Blob([JSON.stringify(exportPayload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const dateStamp = new Date().toISOString().slice(0, 10);
      a.href = url;
      a.download = `GradeOS_Backup_${Runtime.username}_${dateStamp}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('JSON-Export heruntergeladen.');
    });

    // JSON Import Vorschau
    document.getElementById('json-import-file')?.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      const errEl = document.getElementById('import-validation-error');
      const previewEl = document.getElementById('import-preview-panel');
      if (!file) return;

      try {
        const parsed = JSON.parse(await file.text());
        const validationErr = validateImportedJson(parsed);
        if (validationErr) {
          errEl.textContent = validationErr;
          errEl.classList.remove('hidden');
          previewEl.classList.add('hidden');
          Runtime.pendingImportData = null;
          return;
        }

        errEl.classList.add('hidden');
        Runtime.pendingImportData = parsed;
        document.getElementById('import-preview-details').innerHTML = `
          <div><strong>Version:</strong> v${escapeHtml(parsed.version)}</div>
          <div><strong>Exportiert am:</strong> ${formatDateTime(parsed.exportedAt)}</div>
          <div><strong>Fächer in Datei:</strong> ${parsed.subjects.length}</div>
          <div><strong>Noten in Datei:</strong> ${parsed.grades.length}</div>
        `;
        previewEl.classList.remove('hidden');
      } catch (err) {
        errEl.textContent = 'Fehlerhafte JSON-Datei: ' + err.message;
        errEl.classList.remove('hidden');
        previewEl.classList.add('hidden');
      }
    });

    document.getElementById('btn-cancel-import')?.addEventListener('click', () => {
      Runtime.pendingImportData = null;
      document.getElementById('import-preview-panel').classList.add('hidden');
      document.getElementById('json-import-file').value = '';
    });

    document.getElementById('btn-confirm-import')?.addEventListener('click', async () => {
      const inc = Runtime.pendingImportData;
      if (!inc) return;
      const mode = document.getElementById('import-mode-select').value;

      // Schutz vor Datenverlust: immer vorher einen Snapshot anlegen
      await saveEncryptedVault(true);

      if (mode === 'replace') {
        Runtime.data.subjects = inc.subjects || [];
        Runtime.data.grades = inc.grades || [];
        Runtime.data.categories = inc.categories?.length ? inc.categories : DEFAULT_CATEGORIES;
        Runtime.data.history = inc.history || [];
        if (inc.settings) {
          Runtime.data.settings = Object.assign(Runtime.data.settings, inc.settings);
        }
        addHistoryEntry('edited', 'JSON-Import (Vollständig ersetzt)', `Datenstand vom ${formatDateTime(inc.exportedAt)} übernommen.`);
      } else {
        Runtime.data.subjects = mergeById(Runtime.data.subjects, inc.subjects || []);
        Runtime.data.grades = mergeById(Runtime.data.grades, inc.grades || []);
        Runtime.data.categories = mergeById(Runtime.data.categories, inc.categories || []);
        Runtime.data.history = mergeById(Runtime.data.history, inc.history || []).sort(
          (a, b) => new Date(b.timestamp) - new Date(a.timestamp)
        );
        addHistoryEntry('edited', 'JSON-Import (Zusammengeführt)', `Datenstand vom ${formatDateTime(inc.exportedAt)} abgeglichen.`);
      }

      await saveEncryptedVault(true);
      Runtime.pendingImportData = null;
      document.getElementById('import-preview-panel').classList.add('hidden');
      document.getElementById('json-import-file').value = '';
      applyVisualSettings();
      refreshAllViews();
      showToast('Daten erfolgreich importiert und verschlüsselt gespeichert!');
    });
  }

  // ==========================================================================
  // 9. SERVICE WORKER & APP BOOTSTRAP
  // ==========================================================================
  window.addEventListener('DOMContentLoaded', async () => {
    bindEvents();
    await initLockScreen();

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./service-worker.js').catch(() => {
        // Service Worker Registrierung ignoriert, falls über file:// geöffnet
      });
    }
  });
})();
